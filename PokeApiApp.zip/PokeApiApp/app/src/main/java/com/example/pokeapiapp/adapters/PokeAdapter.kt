package com.example.pokeapiapp.adapters

import android.widget.ExpandableListView
import com.example.pokeapiapp.pojos.Pokemon

class PokeAdapter(var pokemons: List<Pokemon>, val clickListener: (Pokemon) -> Unit) : RecyclerView.Adapter {

}